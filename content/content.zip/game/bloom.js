/* Bloom: threshold bright-pass + 2-pass gaussian blur, additively composited
   on top of the screen after FSR has already drawn the sharpened frame.
   Runs on OR.fsr's low-res scene buffer (already rendered, free reuse) at a
   quarter of ITS resolution, so the extra cost is a few small fullscreen
   passes, not another full scene draw. */
(function(){'use strict';
const YV=window.YV;
const VS='varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
/* max-channel rather than luminance: a saturated red taillight (1,0,0) has
   luminance ~.21 (would never clear a .85 luminance threshold) but a max
   channel of 1. — this is what makes colored neon/light bloom work, not
   just white highlights. */
const BRIGHT='precision mediump float;uniform sampler2D tSrc;uniform float threshold;varying vec2 vUv;'+
 'void main(){vec3 c=texture2D(tSrc,vUv).rgb;float l=max(c.r,max(c.g,c.b));float k=clamp((l-threshold)/max(1.-threshold,1e-4),0.,1.);gl_FragColor=vec4(c*k,1.);}';
const BLUR='precision mediump float;uniform sampler2D tSrc;uniform vec2 dir;varying vec2 vUv;'+
 'void main(){vec4 s=texture2D(tSrc,vUv)*.2270270270;s+=texture2D(tSrc,vUv+dir*1.3846153846)*.3162162162;s+=texture2D(tSrc,vUv-dir*1.3846153846)*.3162162162;'+
 's+=texture2D(tSrc,vUv+dir*3.2307692308)*.0702702703;s+=texture2D(tSrc,vUv-dir*3.2307692308)*.0702702703;gl_FragColor=s;}';
const ADD='precision mediump float;uniform sampler2D tSrc;uniform float strength;varying vec2 vUv;'+
 'void main(){gl_FragColor=vec4(texture2D(tSrc,vUv).rgb*strength,1.);}';

YV.Bloom=function(renderer){
 this.r=renderer;this.scene=new THREE.Scene();this.cam=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
 this.mesh=new THREE.Mesh(new THREE.PlaneBufferGeometry(2,2),null);this.mesh.frustumCulled=false;this.scene.add(this.mesh);
 this.bright=new THREE.ShaderMaterial({vertexShader:VS,fragmentShader:BRIGHT,uniforms:{tSrc:{value:null},threshold:{value:.85}},depthTest:false,depthWrite:false});
 this.blur=new THREE.ShaderMaterial({vertexShader:VS,fragmentShader:BLUR,uniforms:{tSrc:{value:null},dir:{value:new THREE.Vector2(1,0)}},depthTest:false,depthWrite:false});
 this.add=new THREE.ShaderMaterial({vertexShader:VS,fragmentShader:ADD,uniforms:{tSrc:{value:null},strength:{value:.8}},depthTest:false,depthWrite:false,
  transparent:true,blending:THREE.AdditiveBlending,depthFunc:THREE.AlwaysDepth});
 this.w=0;this.h=0};

/* lw,lh: size of the already-rendered low-res scene buffer this reads from (OR.fsr.lw/lh) */
YV.Bloom.prototype.size=function(lw,lh){
 const bw=Math.max(16,Math.round(lw/4)),bh=Math.max(16,Math.round(lh/4));
 if(this.bw===bw&&this.bh===bh)return;this.bw=bw;this.bh=bh;
 ['a','b'].forEach(k=>{if(this[k])this[k].dispose()});
 const o={minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,format:THREE.RGBAFormat};
 this.a=new THREE.WebGLRenderTarget(bw,bh,o);this.b=new THREE.WebGLRenderTarget(bw,bh,o)};

/* threshold: 0..1 luminance cutoff (scene is already tonemapped by this point, so this
   catches near-white highlights — sun glints, sky, and any deliberately overbright
   emissive like the brake lights — rather than true pre-tonemap HDR).
   strength: 0..~1.5 additive intensity. Call after OR.fsr.render() has written the
   frame to the screen; this adds glow on top via additive blending, it doesn't clear. */
YV.Bloom.prototype.render=function(srcTexture,threshold,strength){
 if(!this.a)return;const r=this.r;
 this.bright.uniforms.tSrc.value=srcTexture;this.bright.uniforms.threshold.value=threshold;
 this.mesh.material=this.bright;r.setRenderTarget(this.a);r.render(this.scene,this.cam);
 const px=1/this.bw,py=1/this.bh;
 this.blur.uniforms.tSrc.value=this.a.texture;this.blur.uniforms.dir.value.set(px,0);
 this.mesh.material=this.blur;r.setRenderTarget(this.b);r.render(this.scene,this.cam);
 this.blur.uniforms.tSrc.value=this.b.texture;this.blur.uniforms.dir.value.set(0,py);
 this.mesh.material=this.blur;r.setRenderTarget(this.a);r.render(this.scene,this.cam);
 this.add.uniforms.tSrc.value=this.a.texture;this.add.uniforms.strength.value=strength;
 this.mesh.material=this.add;r.setRenderTarget(null);r.autoClear=false;r.render(this.scene,this.cam);r.autoClear=true};
})();
